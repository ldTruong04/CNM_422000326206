const fs = require("fs");
const path = require("path");

const dataFilePath = path.join(__dirname, "..", "data", "products.json");

function readProducts() {
  try {
    const raw = fs.readFileSync(dataFilePath, "utf8");
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    return [];
  }
}

function writeProducts(products) {
  fs.writeFileSync(dataFilePath, JSON.stringify(products, null, 2), "utf8");
}

function normalizePrice(price) {
  const parsed = Number(price);
  return Number.isFinite(parsed) ? parsed : 0;
}

module.exports = {
  all() {
    return readProducts();
  },

  findById(id) {
    return readProducts().find((product) => product.id === String(id)) || null;
  },

  create(input) {
    const products = readProducts();
    const item = {
      id: String(Date.now()),
      name: (input.name || "").trim(),
      description: (input.description || "").trim(),
      price: normalizePrice(input.price),
    };

    products.push(item);
    writeProducts(products);
    return item;
  },

  update(id, input) {
    const products = readProducts();
    const index = products.findIndex((product) => product.id === String(id));

    if (index === -1) {
      return null;
    }

    const current = products[index];
    const updated = {
      ...current,
      name: (input.name || "").trim(),
      description: (input.description || "").trim(),
      price: normalizePrice(input.price),
    };

    products[index] = updated;
    writeProducts(products);
    return updated;
  },

  remove(id) {
    const products = readProducts();
    const nextProducts = products.filter(
      (product) => product.id !== String(id),
    );

    if (nextProducts.length === products.length) {
      return false;
    }

    writeProducts(nextProducts);
    return true;
  },
};
